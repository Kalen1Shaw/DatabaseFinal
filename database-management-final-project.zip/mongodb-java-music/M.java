import com.mongodb.BasicDBObject;
/*
 javac -verbose -cp /home/codio/workspace/mongodb-java-music/mongodb-driver-sync-3.9.0.jar M.java
javac -verbose -cp "/home/codio/workspace/mongodb-java-music/mongodb-driver-legacy-3.9.0.jar" M.java

 
 */
public class M {
    
    public static void main(String args[]) {
        
        
    }
}