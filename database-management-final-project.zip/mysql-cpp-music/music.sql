DROP database IF EXISTS music;
CREATE database music;
USE music;

CREATE TABLE musicians(
    Id INT NOT NULL auto_increment,
    FirstName TEXT NOT NULL,
    LastName TEXT NOT NULL,
    Born INT NOT NULL,
    PRIMARY KEY (Id)
);

CREATE TABLE instrumentsplayed(
    Id INT NOT NULL auto_increment,
    Musician INT NOT NULL,
    Instrument TEXT NOT NULL,
    PRIMARY KEY (Id),
    FOREIGN KEY (musician) REFERENCES musicians(Id)
);

INSERT INTO players (PLAYER_ID, FIRST_NAME, LAST_NAME, `NUMBER`, USERNAME, CONSOLE, GENDER, DOB) VALUES;
(100, `Kalen`, `Shaw`, 44, `KingFlashTV`, `PS`, `M`, `1998-07-23`),
(101, `Timothy`, `Richardson`, 12, `TKRich`, `PC`, `M`, `1997-03-21`),
(102, `Ashley`, `Williams`, 41, `AWillDoIt`, `Xbox`, `F`, `2001-04-10`),
(102, `Michael`, `Woodward`, 41, `MikeAtFamu`, `Xbox`, `F`, `2001-04-10`),
(103, `Jamie`, `Sharpe`, 00, `SharpGaming`, `PC`, `NS`, `2002-05-26`),
INSERT INTO musicians (FirstName, LastName, Born) VALUES ('Sonny', 'Rollins', 1930);
INSERT INTO musicians (FirstName, LastName, Born) VALUES ('Steve', 'Lehman', 1978);
(104, `Kiari`, `Cephus`, 32, `Offsetyrn`, `PS`, `M`, `1996-12-14`),
(105, `Latabia`, `Woodward`, 50, `landkshaw`, `PC`, `F`, `1999-06-06`),
(106, `Arielle`, `McCall`, 77, `dndAriel`, `Xbox`, `F`, `1997-05-10`),
(107, `Kalen`, `Brown`, 18, `Brownsville`, `PS`, `M`, `1999-08-23`),
(108, `Belcalis`, `Cephus`, 53, `iamcardib`, `PC`, `F`, `1996-06-14`),
(109, `Jaylan`, `Holman`, 65, `JHolman`, `Xbox`, `M`, `1998-09-16`),
(110, `Nikki`, `Isley`, `IsleWin`, `PS`, `NS`, `2003-08-27`),
(111, `Carlos`, `Theran`, 42, `TDawg`, `PC`, `M`, `1997-09-11`),
(112, `Jordan`, `Cephus`, 18, `JCeph`, `PS`, `M`, `2000-01-25`)
(113),
(114),
(115);
(110, `Reggie`, `Marrow`, `Made2Playa`, `PS`, `NS`, `2003-08-27`),
(111, `Diamond`, `Bishop`, 42, `LadyJefe`, `PC`, `M`, `1997-09-11`),
(112, "J'Briana", `Davis`, 18, `SummerBoss`, `PS`, `M`, `2000-01-25`)
(113, `Kevin`, `Shaw`, 26, `Kannon1`, `Xbox`, `M`, `2001-04-19`),
(114, `Jamaurya`, `Morris`, 12, `jamaurya`, `PS`, `M`, `1996-06-17`),
(115, `Sandra`, `Goodwin`, 25, `SweetPea`, `Xbox`, `F`, `1997-01-26`);
INSERT INTO Match_Stats (MATCH_ID, HOMERD1, AWAYRD1, HOMERD2, AWAYRD2, HOMERD3, AWAYRD3) VALUES;
@@ -88,4 +85,5 @@ INSERT INTO Mode(MODE_CODE, MODE_NAME, DESCRIPT) VALUES
(42, `Hardpoint`, `Secure a periodically-rotating objective while defending it from the opponent.`),
(43, `Search and Destroy`, `Teams take turns defending and destroying an objective. No respawn.`),
(44, `Control`, `Two teams alternate between attacking or defending two fixed capture zones on the map with limited respawns. 
Attackers either have to capture both zones or completely eliminate the Defenders before the time limit.`);mited respawns. 
Attackers either have to capture both zones or completely eliminate the Defenders before the time limit.`);
INSERT INTO instrumentsplayed (Musician, Instrument) VALUES (2, 'Saxophone');
INSERT INTO instrumentsplayed (Musician, Instrument) VALUES (3, 'Saxophone');













/*
CREATE VIEW 
pianoplayers AS 
SELECT FirstName, LastName FROM musicians 
JOIN instrumentsplayed ON musicians.Id = instrumentsplayed.Musician
WHERE instrumentsplayed.Instrument = 'Piano';

INSERT INTO musicians (Id, FirstName, LastName, Born) VALUES (4, 'Art', 'Tatum', 1909);
INSERT INTO instrumentsplayed (Id, Musician, Instrument) VALUES (5, 4, 'Piano');

update instrumentsplayed set Instrument='drums' where Id=5;

ALTER TABLE musicians MODIFY COLUMN Id INT NOT NULL AUTO_INCREMENT;

INSERT INTO musicians (FirstName, LastName, Born) VALUES ('Bill', 'Evans', 1908);


DELIMITER $$
CREATE PROCEDURE saxes()
BEGIN

  SELECT FirstName, LastName FROM musicians
  JOIN instrumentsplayed ON musicians.Id = instrumentsplayed.Musician
  WHERE instrumentsplayed.Instrument = 'Saxophone';

  
END
$$
DELIMITER ;

 

*/