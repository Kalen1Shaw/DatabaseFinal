#include <stdlib.h>
#include <iostream>
/*
 Include directly the different
 headers from cppconn/ and mysql_driver.h + mysql_util.h
 (and mysql_connection.h). This will reduce your build time!
*/
#include "mysql_finaldb"
#include <cppconn/driver.h>
#include <cppconn/exception.h>
#include <cppconn/resultset.h>
#include <cppconn/statement.h>
#include <cppconn/prepared_statement.h>
using namespace std;

// This program retrieves all of the Players

// Compile:
// g++ -I/usr/include musicapp.cpp -o musicapp -I /usr/local/lib -lmysqlcppconn
// 
// Execute:
// ./musicapp
// 
 sql::Driver *driver;
 sql::Connection *con;
 sql::Statement *stmt;
 sql::ResultSet *res;
 sql::PreparedStatement  *prep_stmt;

void findall();
void findbyid();

int main(void)
{

try {

   
 /* Create a connection */
 driver = get_driver_instance();

  
con = driver->connect("tcp://127.0.0.1:3306", "root", "");

/* Connect to the MySQL music database */
    
 con->setSchema("Players");
 //stmt = con->createStatement();
    
 int option = 7;
 
 while (option != 7) {
     
     cout << endl;
     cout << "1. Add a Player" << endl;
     cout << "2. Find a Player by id" << endl;
     cout << "3. Find a Player by number" << endl;
     cout << "4. Find a Player by dob" << endl;
     cout << "5. Find a Player by Gender" << endl;
     cout << "6. Show all Players" << endl;
     cout << "7. Exit" << endl << endl;
     
     cout << "Choice : ";
     cin >> option;
     
     switch(option) {
        
         case 2: findbyid();
                 break;
             
         case 4: findall();
                 break;
             
             
     }
 }
 

 delete res;
 delete stmt;
 delete con;
} catch (sql::SQLException &e) {
 cout << "# ERR: SQLException in " << __FILE__;
 cout << "(" << __FUNCTION__ << ") on line " << __LINE__ << endl;
 cout << "# ERR: " << e.what();
 cout << " (MySQL error code: " << e.getErrorCode();
 cout << ", SQLState: " << e.getSQLState() << " )" << endl;
}
cout << endl;
return EXIT_SUCCESS;

}

 void findall() {
     
 stmt = con->createStatement();
 res = stmt->executeQuery("SELECT * from Players");
    
 while (res->next()) {
 
 /* Access column data by alias or column name */
     
     cout << res->getString("id") << " ";
     cout << res->getString("firstname") << " ";
     cout << res->getString("lastname") << " ";
     cout << res->getString("CONSOLE") << " ";
     cout << res->getString("USERNAME") << " ";
     cout << res->getString("id") << " ";
     cout << res->getString("GENDER") << " ";
     cout << res->getString("dob") << endl;
 
 }
     
 }

void findbyid() {
     
 
 int id;
    
 cout << "Enter the Players ID : ";
 cin >> id;
    
 
prep_stmt = con->prepareStatement("SELECT * FROM Players WHERE ID = ?");
prep_stmt->setInt(1, id);
res = prep_stmt->executeQuery();


 while (res->next()) {

 /* Access column data by alias or column name */
     
     cout << res->getString("id") << " ";
     cout << res->getString("firstname") << " ";
     cout << res->getString("lastname") << " ";
     cout << res->getString("number") << " ";
      cout << res->getString("gender") << " ";
     cout << res->getString("born") << endl;
 
 }
     
 }